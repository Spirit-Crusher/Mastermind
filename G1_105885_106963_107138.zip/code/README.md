Para compilar todos os nossos programas, basta correr “make” na diretoria principal. Para compilar cada programa
individualmente, basta correr “make serv”, “make log” ou “make apl”, respectivamente. Existe também a opção de compilar
e correr cada programa individualmente com: “make run_s”, “make run_l” e “make run_a” respectivamente. (Sempre
executado na diretoria principal).