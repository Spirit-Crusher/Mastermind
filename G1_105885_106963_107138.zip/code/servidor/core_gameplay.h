#ifndef CORE_GAMEPLAY_H
#define CORE_GAMEPLAY_H

/****************** Includes *******************/
#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#include "../mastermind.h"
#include <string.h>

/***************************  Fuctions ***************************/
void generate_key(char* key, game_diff_t level);

#endif